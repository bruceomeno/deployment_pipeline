package deploymentpipeline.deploymentpipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeploymentPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeploymentPipelineApplication.class, args);
	}

}
